// eslint-disable-next-line no-unused-vars
import {React} from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { Container  } from '@mui/material';

// eslint-disable-next-line react/prop-types
export function Layout({children}) {
    return(

        <>
        <Header/>
        <Container  maxWidth='xl' style={{paddingTop:'1rem',paddingBottom:'4.5rem'}}>
        {children}

        </Container>
        <Footer/>
        </>
    )
    
}